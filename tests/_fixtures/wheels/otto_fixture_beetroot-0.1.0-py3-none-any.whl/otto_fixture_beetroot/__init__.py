"""otto test fixture package. Never published to any index."""
__version__ = "0.1.0"


def beet() -> str:
    return "otto-fixture-beetroot"
